prompt --application/deployment/install/install_blood_donation_data_sql
begin
--   Manifest
--     INSTALL: INSTALL-Blood_Donation_Data.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9473490759070649622)
,p_install_id=>wwv_flow_imp.id(103310314012925322073)
,p_name=>'Blood_Donation_Data.sql'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --USERS_INFO: 48/10000 rows exported, APEX$DATA$PKG/USERS_INFO$709576',
'    apex_data_install.load_supporting_object_data(p_table_name => ''USERS_INFO'', p_delete_after_install => true );',
'    --DONOR_INFO: 25/10000 rows exported, APEX$DATA$PKG/DONOR_INFO$221458',
'    apex_data_install.load_supporting_object_data(p_table_name => ''DONOR_INFO'', p_delete_after_install => true );',
'    --PATIENT_INFO: 11/10000 rows exported, APEX$DATA$PKG/PATIENT_INFO$810431',
'    apex_data_install.load_supporting_object_data(p_table_name => ''PATIENT_INFO'', p_delete_after_install => true );',
'    --RECIPIENT_INFO: 19/10000 rows exported, APEX$DATA$PKG/RECIPIENT_INFO$138486',
'    apex_data_install.load_supporting_object_data(p_table_name => ''RECIPIENT_INFO'', p_delete_after_install => true );',
'    --ADMINS: 1/10000 rows exported, APEX$DATA$PKG/ADMINS$281322',
'    apex_data_install.load_supporting_object_data(p_table_name => ''ADMINS'', p_delete_after_install => true );',
'    --BLOOD_BANKS: 8/10000 rows exported, APEX$DATA$PKG/BLOOD_BANKS$358425',
'    apex_data_install.load_supporting_object_data(p_table_name => ''BLOOD_BANKS'', p_delete_after_install => true );',
'    --CENTER_LOCATION: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''CENTER_LOCATION'', p_delete_after_install => true );',
'    --DONATION_CENTERS: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''DONATION_CENTERS'', p_delete_after_install => true );',
'    --DONATION_CENTERS_HOSPITAL: 21/10000 rows exported, APEX$DATA$PKG/DONATION_CENTERS_HOSPITA$108229',
'    apex_data_install.load_supporting_object_data(p_table_name => ''DONATION_CENTERS_HOSPITAL'', p_delete_after_install => true );',
'    --DONOR_HISTORY: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''DONOR_HISTORY'', p_delete_after_install => true );',
'    --FEEDBACKS: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''FEEDBACKS'', p_delete_after_install => true );',
'    --HTMLDB_PLAN_TABLE: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''HTMLDB_PLAN_TABLE'', p_delete_after_install => true );',
'    --LOCATIONS: 58/10000 rows exported, APEX$DATA$PKG/LOCATIONS$289750',
'    apex_data_install.load_supporting_object_data(p_table_name => ''LOCATIONS'', p_delete_after_install => true );',
'    --NOTIFICATIONS: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''NOTIFICATIONS'', p_delete_after_install => true );',
'    --RARE_BLOOD_GROUP: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''RARE_BLOOD_GROUP'', p_delete_after_install => true );',
'    --SOCIAL_ORGANIZATION: 10/10000 rows exported, APEX$DATA$PKG/SOCIAL_ORGANIZATION$259941',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SOCIAL_ORGANIZATION'', p_delete_after_install => true );',
'    --USER_LOCATION: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''USER_LOCATION'', p_delete_after_install => true );',
'    --DONOR_HEALTH: 2/10000 rows exported, APEX$DATA$PKG/DONOR_HEALTH$329390',
'    apex_data_install.load_supporting_object_data(p_table_name => ''DONOR_HEALTH'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
