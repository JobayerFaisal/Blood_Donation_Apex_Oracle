prompt --application/deployment/install/install_blood_donation_function_sql
begin
--   Manifest
--     INSTALL: INSTALL-Blood_Donation_function.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9472512141630618743)
,p_install_id=>wwv_flow_imp.id(103310314012925322073)
,p_name=>'Blood_Donation_function.sql'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace FUNCTION calculate_distance (',
'    lat1 NUMBER, lon1 NUMBER,',
'    lat2 NUMBER, lon2 NUMBER',
') RETURN NUMBER IS',
'    RADIUS CONSTANT NUMBER := 6371; -- Earth''s radius in kilometers',
'    dlat NUMBER;',
'    dlon NUMBER;',
'    a NUMBER;',
'    c NUMBER;',
'    pi CONSTANT NUMBER := 3.141592653589793;',
'BEGIN',
'    -- Convert degrees to radians',
'    dlat := (lat2 - lat1) * (pi / 180);',
'    dlon := (lon2 - lon1) * (pi / 180);',
'',
'    a := SIN(dlat / 2) * SIN(dlat / 2) +',
'         COS(lat1 * (pi / 180)) * COS(lat2 * (pi / 180)) *',
'         SIN(dlon / 2) * SIN(dlon / 2);',
'',
'    c := 2 * ATAN2(SQRT(a), SQRT(1 - a));',
'',
'    RETURN RADIUS * c;',
'END;',
'/',
'create or replace FUNCTION custom_auth (',
'    p_username IN VARCHAR2,',
'    p_password IN VARCHAR2',
') RETURN BOOLEAN IS',
'    l_count NUMBER;',
'BEGIN',
'    -- Example authentication logic',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM users_table',
'    WHERE username = p_username',
'      AND password = p_password; -- Hash password if necessary',
'',
'    RETURN l_count = 1;',
'END;',
'/',
'create or replace FUNCTION CUSTOM_AUTHENTICATION (',
'    P9999_USERNAME IN VARCHAR2,',
'    P9999_PASSWORD IN VARCHAR2',
') RETURN BOOLEAN IS',
'    L_COUNT NUMBER;',
'BEGIN',
'    -- Query to validate email and password',
'    SELECT COUNT(*)',
'    INTO L_COUNT',
'    FROM USERS_INFO',
'    WHERE EMAIL = P9999_USERNAME',
'      AND PASSWORD = P9999_PASSWORD; -- Use hashed comparison if passwords are hashed.',
'',
'    -- Return true if a matching record is found',
'    RETURN L_COUNT = 1;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RETURN FALSE; -- In case of any exception, return false',
'END;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472512224597618744)
,p_script_id=>wwv_flow_imp.id(9472512141630618743)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'CALCULATE_DISTANCE'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472512448526618745)
,p_script_id=>wwv_flow_imp.id(9472512141630618743)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'CUSTOM_AUTH'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472512619884618745)
,p_script_id=>wwv_flow_imp.id(9472512141630618743)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'CUSTOM_AUTHENTICATION'
);
wwv_flow_imp.component_end;
end;
/
