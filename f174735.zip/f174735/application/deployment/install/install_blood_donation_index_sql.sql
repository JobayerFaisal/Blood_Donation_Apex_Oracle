prompt --application/deployment/install/install_blood_donation_index_sql
begin
--   Manifest
--     INSTALL: INSTALL-Blood_Donation_index.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9472334005548343464)
,p_install_id=>wwv_flow_imp.id(103310314012925322073)
,p_name=>'Blood_Donation_index.sql'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE UNIQUE INDEX "ADMINS_PK" ON "ADMINS" ("USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "BLOOD_BANK_HOSPITAL_PK" ON "BLOOD_BANKS" ("ORGANIZATION_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "CENTER_LOCATION_PK" ON "CENTER_LOCATION" ("DONATION_CENTERS_CENTER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "DONATION_CENTERS_PK" ON "DONATION_CENTERS_HOSPITAL" ("CENTER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "DONOR_HEALTH__IDX" ON "DONOR_HEALTH" ("USERS_INFO_USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "DONOR_HISTORY_PK" ON "DONOR_HISTORY" ("DONATION_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "DONOR_INFO_PK" ON "DONOR_INFO" ("USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "FEEDBACKS_PK" ON "FEEDBACKS" ("FEEDBACK_ID", "USERS_INFO_USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "LOCATIONS_PK" ON "LOCATIONS" ("AREA_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "NOTIFICATIONS_PK" ON "NOTIFICATIONS" ("NOTIFICATION_ID", "USERS_INFO_USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "PATIENT_INFO_PK" ON "PATIENT_INFO" ("PATIENT_ID", "USERS_INFO_USER_ID", "DONATION_CENTERS_CENTER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "RARE_BLOOD_GROUP_PK" ON "RARE_BLOOD_GROUP" ("RECORD_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "RECIPIENT_INFO_PK" ON "RECIPIENT_INFO" ("USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SOCIAL_ORGANIZATION_PK" ON "SOCIAL_ORGANIZATION" ("ORGANIZATION_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "USERS_INFO_PK" ON "USERS_INFO" ("USER_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "USER_LOCATION_PK" ON "USER_LOCATION" ("USERS_INFO_USER_ID") ',
'  ; '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472334143489343466)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'ADMINS_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472334342773343466)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'BLOOD_BANK_HOSPITAL_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472334508334343466)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'CENTER_LOCATION_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472334764366343466)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'DONATION_CENTERS_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472334900678343466)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'DONOR_HEALTH__IDX'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472335116773343466)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'DONOR_HISTORY_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472335370458343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'DONOR_INFO_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472335535863343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FEEDBACKS_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472335768713343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'LOCATIONS_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472335949794343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'NOTIFICATIONS_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472336124194343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PATIENT_INFO_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472336353135343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'RARE_BLOOD_GROUP_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472336575265343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'RECIPIENT_INFO_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472336792445343467)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SOCIAL_ORGANIZATION_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472336912545343468)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'USERS_INFO_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472337175734343468)
,p_script_id=>wwv_flow_imp.id(9472334005548343464)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'USER_LOCATION_PK'
);
wwv_flow_imp.component_end;
end;
/
