prompt --application/deployment/install/install_blood_donation_sequence_sql
begin
--   Manifest
--     INSTALL: INSTALL-Blood_Donation_Sequence.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9470242607570586594)
,p_install_id=>wwv_flow_imp.id(103310314012925322073)
,p_name=>'Blood_Donation_Sequence.sql'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   CREATE SEQUENCE  "BLOOD_BANK_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "CENTER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 22 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "DONATION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "FEEDBACK_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 14 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "NOTIFICATION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "PATIENT_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 55 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "USER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 57 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ; '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470242760444586598)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'BLOOD_BANK_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470242949879586599)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'CENTER_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470243122881586599)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'DONATION_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470243347878586600)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'FEEDBACK_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470243560981586600)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'NOTIFICATION_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470243715350586600)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'PATIENT_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9470243990822586600)
,p_script_id=>wwv_flow_imp.id(9470242607570586594)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'USER_SEQ'
);
wwv_flow_imp.component_end;
end;
/
