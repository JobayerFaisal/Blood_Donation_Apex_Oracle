prompt --application/deployment/install/install_blood_donation_table_sql
begin
--   Manifest
--     INSTALL: INSTALL-Blood_Donation_Table.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9472290655720335724)
,p_install_id=>wwv_flow_imp.id(103310314012925322073)
,p_name=>'Blood_Donation_Table.sql'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE TABLE "ADMINS" ',
'   (	"USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"NAME" VARCHAR2(50), ',
'	"EMAIL" VARCHAR2(50), ',
'	"PASSWORD" VARCHAR2(50) NOT NULL ENABLE, ',
'	 CONSTRAINT "ADMINS_PK" PRIMARY KEY ("USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "BLOOD_BANKS" ',
'   (	"ORGANIZATION_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"ORGANIZATION_NAME" VARCHAR2(100) NOT NULL ENABLE, ',
'	"CONTACT_NO" VARCHAR2(16), ',
'	"ADDRESS" VARCHAR2(100) NOT NULL ENABLE, ',
'	"DISTRICT" VARCHAR2(50) NOT NULL ENABLE, ',
'	 CONSTRAINT "BLOOD_BANK_HOSPITAL_PK" PRIMARY KEY ("ORGANIZATION_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "CENTER_LOCATION" ',
'   (	"DONATION_CENTERS_CENTER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	 CONSTRAINT "CENTER_LOCATION_PK" PRIMARY KEY ("DONATION_CENTERS_CENTER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DONATION_CENTERS" ',
'   (	"CENTER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"CENTER_NAME" VARCHAR2(100) NOT NULL ENABLE, ',
'	"CENTER_CONTACT" VARCHAR2(11), ',
'	"CENTER_ADDRESS" VARCHAR2(100), ',
'	"DISTRICT" VARCHAR2(25) NOT NULL ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DONATION_CENTERS_HOSPITAL" ',
'   (	"CENTER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"CENTER_NAME" VARCHAR2(100) NOT NULL ENABLE, ',
'	"CENTER_CONTACT" VARCHAR2(16), ',
'	"CENTER_ADDRESS" VARCHAR2(100), ',
'	"DISTRICT" VARCHAR2(25) NOT NULL ENABLE, ',
'	"HOSPITAL_AREA" VARCHAR2(50), ',
'	 CONSTRAINT "DONATION_CENTERS_PK" PRIMARY KEY ("CENTER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DONOR_HEALTH" ',
'   (	"LAST_DATE_OF_DONATION" DATE, ',
'	"AGE" NUMBER, ',
'	"WEIGHT" NUMBER, ',
'	"HEALTH_CONDITION" VARCHAR2(25), ',
'	"CHRONIC_CONDITION" VARCHAR2(25), ',
'	"AVAILIBILITY" VARCHAR2(25), ',
'	"EMERGENCY_CONTACT" VARCHAR2(11), ',
'	"USERS_INFO_USER_ID" VARCHAR2(15) NOT NULL ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DONOR_HISTORY" ',
'   (	"DONATION_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"DATE_OF_DONATION" DATE, ',
'	"RATINGS" NUMBER(2,2), ',
'	"FEEDBACKS" VARCHAR2(300), ',
'	"USERS_INFO_USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	 CONSTRAINT "DONOR_HISTORY_PK" PRIMARY KEY ("DONATION_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DONOR_INFO" ',
'   (	"USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"BLOOD_GROUP" VARCHAR2(10), ',
'	"ADDRESS" VARCHAR2(100), ',
'	"DISTRICT" VARCHAR2(50), ',
'	"EMERGENCY_CONTACT" VARCHAR2(22), ',
'	"CONTACT_NO_2" VARCHAR2(22), ',
'	"LIVING_AREA" VARCHAR2(50), ',
'	"NAME" VARCHAR2(50) NOT NULL ENABLE, ',
'	"EMAIL" VARCHAR2(50) NOT NULL ENABLE, ',
'	"LIVING_AREA_CODE" VARCHAR2(15), ',
'	"LATITUDE" NUMBER(10,6), ',
'	"LONGITUDE" NUMBER(10,6), ',
'	"AGE" NUMBER, ',
'	"WEIGHT" NUMBER, ',
'	"HEALTH_CONDITION" VARCHAR2(50), ',
'	"CHRONIC_CONDITION" VARCHAR2(50), ',
'	"AVAILIBILITY" VARCHAR2(50), ',
'	 CONSTRAINT "DONOR_INFO_PK" PRIMARY KEY ("USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "FEEDBACKS" ',
'   (	"FEEDBACK_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"FEEDBACK_TEXT" VARCHAR2(300), ',
'	"FEED_DATE" DATE, ',
'	"USERS_INFO_USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	 CONSTRAINT "FEEDBACKS_PK" PRIMARY KEY ("FEEDBACK_ID", "USERS_INFO_USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "HTMLDB_PLAN_TABLE" ',
'   (	"STATEMENT_ID" VARCHAR2(30), ',
'	"PLAN_ID" NUMBER, ',
'	"TIMESTAMP" DATE, ',
'	"REMARKS" VARCHAR2(4000), ',
'	"OPERATION" VARCHAR2(30), ',
'	"OPTIONS" VARCHAR2(255), ',
'	"OBJECT_NODE" VARCHAR2(128), ',
'	"OBJECT_OWNER" VARCHAR2(128), ',
'	"OBJECT_NAME" VARCHAR2(128), ',
'	"OBJECT_ALIAS" VARCHAR2(261), ',
'	"OBJECT_INSTANCE" NUMBER(*,0), ',
'	"OBJECT_TYPE" VARCHAR2(128), ',
'	"OPTIMIZER" VARCHAR2(255), ',
'	"SEARCH_COLUMNS" NUMBER, ',
'	"ID" NUMBER(*,0), ',
'	"PARENT_ID" NUMBER(*,0), ',
'	"DEPTH" NUMBER(*,0), ',
'	"POSITION" NUMBER(*,0), ',
'	"COST" NUMBER(*,0), ',
'	"CARDINALITY" NUMBER(*,0), ',
'	"BYTES" NUMBER(*,0), ',
'	"OTHER_TAG" VARCHAR2(255), ',
'	"PARTITION_START" VARCHAR2(255), ',
'	"PARTITION_STOP" VARCHAR2(255), ',
'	"PARTITION_ID" NUMBER(*,0), ',
'	"OTHER" LONG, ',
'	"DISTRIBUTION" VARCHAR2(30), ',
'	"CPU_COST" NUMBER(*,0), ',
'	"IO_COST" NUMBER(*,0), ',
'	"TEMP_SPACE" NUMBER(*,0), ',
'	"ACCESS_PREDICATES" VARCHAR2(4000), ',
'	"FILTER_PREDICATES" VARCHAR2(4000), ',
'	"PROJECTION" VARCHAR2(4000), ',
'	"TIME" NUMBER(*,0), ',
'	"QBLOCK_NAME" VARCHAR2(128)',
'   ) ;',
'',
'  CREATE TABLE "LOCATIONS" ',
'   (	"AREA_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"AREA_NAME" VARCHAR2(25) NOT NULL ENABLE, ',
'	"LATITUDE" NUMBER(10,6), ',
'	"LONGITUDE" NUMBER(10,6), ',
'	 CONSTRAINT "LOCATIONS_PK" PRIMARY KEY ("AREA_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "NOTIFICATIONS" ',
'   (	"NOTIFICATION_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"MESSEGE" VARCHAR2(300), ',
'	"NOTI_DATE" DATE, ',
'	"USERS_INFO_USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	 CONSTRAINT "NOTIFICATIONS_PK" PRIMARY KEY ("NOTIFICATION_ID", "USERS_INFO_USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "PATIENT_INFO" ',
'   (	"PATIENT_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"BLOOD_GROUP" VARCHAR2(10) NOT NULL ENABLE, ',
'	"BLOOD_COUNT" NUMBER, ',
'	"DONATION_DATE" DATE, ',
'	"DONATION_TIME" VARCHAR2(15), ',
'	"AGE" NUMBER, ',
'	"CAUSE" VARCHAR2(45) NOT NULL ENABLE, ',
'	"URGENCY_LEVEL" VARCHAR2(15) NOT NULL ENABLE, ',
'	"USERS_INFO_USER_ID" VARCHAR2(15), ',
'	"PATIENTS_HOSPITAL" VARCHAR2(100), ',
'	"HOSPITAL_AREA" VARCHAR2(50), ',
'	"DONATION_CENTERS_CENTER_ID" VARCHAR2(15), ',
'	"PATIENT_NAME" VARCHAR2(50), ',
'	"LATITUDE" NUMBER(10,6), ',
'	"LONGITUDE" NUMBER(10,6), ',
'	"PATIENT_CONTACT" VARCHAR2(16), ',
'	 CONSTRAINT "PATIENT_INFO_PK" PRIMARY KEY ("PATIENT_ID", "USERS_INFO_USER_ID", "DONATION_CENTERS_CENTER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "RARE_BLOOD_GROUP" ',
'   (	"RECORD_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"BLOOD_GROUP" VARCHAR2(10) NOT NULL ENABLE, ',
'	"DESCRIPTION" VARCHAR2(300), ',
'	"AVAILABILITY_STATUS" VARCHAR2(25) NOT NULL ENABLE, ',
'	 CONSTRAINT "RARE_BLOOD_GROUP_PK" PRIMARY KEY ("RECORD_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "RECIPIENT_INFO" ',
'   (	"USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"CONTACT_NO_1" VARCHAR2(11), ',
'	"CONTACT_NO_2" VARCHAR2(11), ',
'	"ADDRESS" VARCHAR2(100), ',
'	"NAME" VARCHAR2(50), ',
'	"EMAIL" VARCHAR2(50), ',
'	 CONSTRAINT "RECIPIENT_INFO_PK" PRIMARY KEY ("USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "SOCIAL_ORGANIZATION" ',
'   (	"ORGANIZATION_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"ORGANIZATION_NAME" VARCHAR2(100) NOT NULL ENABLE, ',
'	"CONTACT_NO" VARCHAR2(18), ',
'	"ADDRESS" VARCHAR2(100) NOT NULL ENABLE, ',
'	"DISTRICT" VARCHAR2(50), ',
'	 CONSTRAINT "SOCIAL_ORGANIZATION_PK" PRIMARY KEY ("ORGANIZATION_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "USERS_INFO" ',
'   (	"USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	"USER_TYPE" VARCHAR2(15) NOT NULL ENABLE, ',
'	"EMAIL" VARCHAR2(50) NOT NULL ENABLE, ',
'	"PASSWORD" VARCHAR2(50) NOT NULL ENABLE, ',
'	"NAME" VARCHAR2(50) NOT NULL ENABLE, ',
'	 CONSTRAINT "USERS_INFO_PK" PRIMARY KEY ("USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "USER_LOCATION" ',
'   (	"USERS_INFO_USER_ID" VARCHAR2(15) NOT NULL ENABLE, ',
'	 CONSTRAINT "USER_LOCATION_PK" PRIMARY KEY ("USERS_INFO_USER_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_INSERT_ADMIN" ',
'AFTER INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Admin''',
'    IF :NEW.USER_TYPE = ''Admin'' THEN',
'        -- Insert into ADMINS table using the values from USERS_INFO',
'        INSERT INTO ADMINS (USER_ID, NAME, EMAIL, PASSWORD)',
'        VALUES (:NEW.USER_ID, :NEW.NAME, :NEW.EMAIL, :NEW.PASSWORD);',
'    END IF;',
'END;',
'/',
'ALTER TRIGGER "TRG_INSERT_ADMIN" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_INSERT_DONOR" ',
'AFTER INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Donor''',
'    IF :NEW.USER_TYPE = ''Donor'' THEN',
'        -- Insert into DONOR_INFO table',
'        INSERT INTO DONOR_INFO (',
'            USER_ID, BLOOD_GROUP, ADDRESS, DISTRICT, EMERGENCY_CONTACT, CONTACT_NO_2, ',
'            LIVING_AREA, LIVING_AREA_CODE, NAME, EMAIL',
'        )',
'        VALUES (',
'            :NEW.USER_ID,      -- User ID from USERS_INFO',
'            NULL,              -- BLOOD_GROUP to be updated later',
'            NULL,              -- ADDRESS to be updated later',
'            NULL,              -- DISTRICT to be updated later',
'            NULL,              -- Default value for EMERGENCY_CONTACT',
'            NULL,              -- CONTACT_NO_2 to be updated later',
'            NULL,              -- LIVING_AREA to be updated later',
'            NULL,              -- LIVING_AREA_CODE to be updated later',
'            :NEW.NAME,         -- Name from USERS_INFO',
'            :NEW.EMAIL         -- Email from USERS_INFO',
'        );',
'    END IF;',
'END;',
'/',
'ALTER TRIGGER "TRG_INSERT_DONOR" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_INSERT_RECIPIENT" ',
'AFTER INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Recipient''',
'    IF :NEW.USER_TYPE = ''General'' THEN',
'        -- Insert into RECIPIENT_INFO table',
'        INSERT INTO RECIPIENT_INFO (USER_ID, CONTACT_NO_1, CONTACT_NO_2, ADDRESS, NAME, EMAIL)',
'        VALUES (',
'            :NEW.USER_ID,   -- User ID from USERS_INFO',
'            NULL,           -- CONTACT_NO_1 to be updated later',
'            NULL,           -- CONTACT_NO_2 to be updated later',
'            NULL,           -- ADDRESS to be updated later',
'            :NEW.NAME,      -- Name from USERS_INFO',
'            :NEW.EMAIL      -- Email from USERS_INFO',
'        );',
'    END IF;',
'END;',
'/',
'ALTER TRIGGER "TRG_INSERT_RECIPIENT" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_UPDATE_DONOR" ',
'AFTER UPDATE ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Donor''',
'    IF :OLD.USER_TYPE = ''Donor'' THEN',
'        -- Update the DONOR_INFO table with the new data',
'        UPDATE DONOR_INFO',
'        SET ',
'            NAME = :NEW.NAME,',
'            EMAIL = :NEW.EMAIL,',
'            ADDRESS = :NEW.ADDRESS,',
'            DISTRICT = :NEW.DISTRICT,',
'            EMERGENCY_CONTACT = :NEW.EMERGENCY_CONTACT,',
'            CONTACT_NO_2 = :NEW.CONTACT_NO_2,',
'            LIVING_AREA = :NEW.LIVING_AREA,',
'            LIVING_AREA_CODE = :NEW.LIVING_AREA_CODE',
'        WHERE USER_ID = :OLD.USER_ID;',
'    END IF;',
'END;',
'/',
'ALTER TRIGGER "TRG_UPDATE_DONOR" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_USER_ID" ',
'BEFORE INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    :NEW.USER_ID := ''USR-'' || LPAD(user_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_USER_ID" ENABLE;',
'',
'  ALTER TABLE "DONOR_INFO" ADD CONSTRAINT "DONOR_INFO_USERS_INFO_FK" FOREIGN KEY ("USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'  ALTER TABLE "DONOR_INFO" ADD CONSTRAINT "FK_LIVING_AREA_CODE" FOREIGN KEY ("LIVING_AREA_CODE")',
'	  REFERENCES "LOCATIONS" ("AREA_ID") ENABLE;',
'',
'  ALTER TABLE "RECIPIENT_INFO" ADD CONSTRAINT "RECIPIENT_INFO_USERS_INFO_FK" FOREIGN KEY ("USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  ALTER TABLE "PATIENT_INFO" ADD CONSTRAINT "PATIENT_INFO_DONATION_CENTERS_FK" FOREIGN KEY ("DONATION_CENTERS_CENTER_ID")',
'	  REFERENCES "DONATION_CENTERS_HOSPITAL" ("CENTER_ID") ENABLE;',
'  ALTER TABLE "PATIENT_INFO" ADD CONSTRAINT "PATIENT_INFO_USERS_INFO_FK" FOREIGN KEY ("USERS_INFO_USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_PATIENT_ID" ',
'BEFORE INSERT ON PATIENT_INFO',
'FOR EACH ROW',
'BEGIN',
'    :NEW.PATIENT_ID := ''PAT-'' || LPAD(patient_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_PATIENT_ID" ENABLE;',
'',
'  ALTER TABLE "ADMINS" ADD CONSTRAINT "ADMINS_USERS_INFO_FK" FOREIGN KEY ("USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BLOOD_BANK_ID" ',
'BEFORE INSERT ON "BLOOD_BANKS"',
'FOR EACH ROW',
'BEGIN',
'    :NEW.ORGANIZATION_ID:= ''BANK-'' || LPAD(blood_bank_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_BLOOD_BANK_ID" ENABLE;',
'',
'  ALTER TABLE "CENTER_LOCATION" ADD CONSTRAINT "CENTER_LOCATION_DONATION_CENTERS_FK" FOREIGN KEY ("DONATION_CENTERS_CENTER_ID")',
'	  REFERENCES "DONATION_CENTERS_HOSPITAL" ("CENTER_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_CENTER_ID" ',
'BEFORE INSERT ON "DONATION_CENTERS_HOSPITAL"',
'FOR EACH ROW',
'BEGIN',
'    :NEW.CENTER_ID := ''CENT-'' || LPAD(center_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_CENTER_ID" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UPDATE_PATIENT_HOSPITAL_DETAILS" ',
'AFTER INSERT ON DONATION_CENTERS_HOSPITAL',
'FOR EACH ROW',
'BEGIN',
'    -- Update the PATIENT_INFO table with the center name and area from DONATION_CENTERS_HOSPITAL',
'    UPDATE PATIENT_INFO',
'    SET PATIENTS_HOSPITAL = :NEW.CENTER_NAME,',
'        HOSPITAL_AREA = :NEW.HOSPITAL_AREA',
'    WHERE DONATION_CENTERS_CENTER_ID = :NEW.CENTER_ID;',
'END;',
'/',
'ALTER TRIGGER "UPDATE_PATIENT_HOSPITAL_DETAILS" ENABLE;',
'',
'  ALTER TABLE "DONOR_HEALTH" ADD CONSTRAINT "DONOR_HEALTH_USERS_INFO_FK" FOREIGN KEY ("USERS_INFO_USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  CREATE UNIQUE INDEX "DONOR_HEALTH__IDX" ON "DONOR_HEALTH" ("USERS_INFO_USER_ID") ',
'  ;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_UPDATE_DONOR_INFO" ',
'AFTER UPDATE ON DONOR_HEALTH',
'FOR EACH ROW',
'BEGIN',
'    UPDATE DONOR_INFO',
'    SET ',
'        CONTACT_NO_1 = :NEW.EMERGENCY_CONTACT',
'    WHERE USER_ID = :NEW.USERS_INFO_USER_ID;',
'',
'    -- Optionally, handle insert if no matching record exists',
'    IF SQL%ROWCOUNT = 0 THEN',
'        INSERT INTO DONOR_INFO (',
'            USER_ID, ',
'            BLOOD_GROUP, ',
'            ADDRESS, ',
'            DISTRICT, ',
'            CONTACT_NO_1, ',
'            CONTACT_NO_2, ',
'            LIVING_AREA, ',
'            NAME, ',
'            EMAIL, ',
'            LIVING_AREA_CODE, ',
'            LATITUDE, ',
'            LONGITUDE',
'        )',
'        VALUES (',
'            :NEW.USERS_INFO_USER_ID,',
'            NULL, -- Set default or dynamic values',
'            NULL,',
'            NULL,',
'            :NEW.EMERGENCY_CONTACT,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL',
'        );',
'    END IF;',
'END;',
'/',
'ALTER TRIGGER "TRG_UPDATE_DONOR_INFO" ENABLE;',
'',
'  ALTER TABLE "DONOR_HISTORY" ADD CONSTRAINT "DONOR_HISTORY_USERS_INFO_FK" FOREIGN KEY ("USERS_INFO_USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_DONATION_ID" ',
'BEFORE INSERT ON DONOR_HISTORY',
'FOR EACH ROW',
'BEGIN',
'    :NEW.DONATION_ID := ''DON-'' || LPAD(donation_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_DONATION_ID" ENABLE;',
'',
'  ALTER TABLE "FEEDBACKS" ADD CONSTRAINT "FEEDBACKS_USERS_INFO_FK" FOREIGN KEY ("USERS_INFO_USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_FEEDBACK_ID" ',
'BEFORE INSERT ON FEEDBACKS',
'FOR EACH ROW',
'BEGIN',
'    :NEW.FEEDBACK_ID := ''FEED-'' || LPAD(feedback_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_FEEDBACK_ID" ENABLE;',
'',
'  ALTER TABLE "NOTIFICATIONS" ADD CONSTRAINT "NOTIFICATIONS_USERS_INFO_FK" FOREIGN KEY ("USERS_INFO_USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_NOTIFICATION_ID" ',
'BEFORE INSERT ON NOTIFICATIONS',
'FOR EACH ROW',
'BEGIN',
'    :NEW.NOTIFICATION_ID := ''NOTI-'' || LPAD(notification_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'ALTER TRIGGER "TRG_NOTIFICATION_ID" ENABLE;',
'',
'  ALTER TABLE "RARE_BLOOD_GROUP" ADD CONSTRAINT "RARE_BLOOD_GROUP_DONOR_INFO_FK" FOREIGN KEY ("USER_ID")',
'	  REFERENCES "DONOR_INFO" ("USER_ID") ENABLE;',
'',
'  ALTER TABLE "USER_LOCATION" ADD CONSTRAINT "USER_LOCATION_USERS_INFO_FK" FOREIGN KEY ("USERS_INFO_USER_ID")',
'	  REFERENCES "USERS_INFO" ("USER_ID") ENABLE; '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472291536875335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ADMINS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472291991788335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'BLOOD_BANKS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472292149994335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'CENTER_LOCATION'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472292507928335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DONATION_CENTERS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472292397203335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DONATION_CENTERS_HOSPITAL'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472292790464335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DONOR_HEALTH'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472292927802335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DONOR_HISTORY'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472290900059335726)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DONOR_INFO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472293111877335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FEEDBACKS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472293331324335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'HTMLDB_PLAN_TABLE'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472291742438335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'LOCATIONS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472293575226335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'NOTIFICATIONS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472291324164335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'PATIENT_INFO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472293777892335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RARE_BLOOD_GROUP'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472291150992335727)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RECIPIENT_INFO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472293921548335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SOCIAL_ORGANIZATION'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472290720033335726)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'USERS_INFO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472294114814335728)
,p_script_id=>wwv_flow_imp.id(9472290655720335724)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'USER_LOCATION'
);
wwv_flow_imp.component_end;
end;
/
