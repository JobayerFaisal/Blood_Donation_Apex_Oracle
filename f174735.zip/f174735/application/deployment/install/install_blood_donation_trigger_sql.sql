prompt --application/deployment/install/install_blood_donation_trigger_sql
begin
--   Manifest
--     INSTALL: INSTALL-Blood_Donation_Trigger.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9472443382508610149)
,p_install_id=>wwv_flow_imp.id(103310314012925322073)
,p_name=>'Blood_Donation_Trigger.sql'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace TRIGGER trg_blood_bank_id',
'BEFORE INSERT ON "BLOOD_BANKS"',
'FOR EACH ROW',
'BEGIN',
'    :NEW.ORGANIZATION_ID:= ''BANK-'' || LPAD(blood_bank_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER trg_center_id',
'BEFORE INSERT ON "DONATION_CENTERS_HOSPITAL"',
'FOR EACH ROW',
'BEGIN',
'    :NEW.CENTER_ID := ''CENT-'' || LPAD(center_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER trg_donation_id',
'BEFORE INSERT ON DONOR_HISTORY',
'FOR EACH ROW',
'BEGIN',
'    :NEW.DONATION_ID := ''DON-'' || LPAD(donation_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER trg_feedback_id',
'BEFORE INSERT ON FEEDBACKS',
'FOR EACH ROW',
'BEGIN',
'    :NEW.FEEDBACK_ID := ''FEED-'' || LPAD(feedback_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER TRG_INSERT_ADMIN',
'AFTER INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Admin''',
'    IF :NEW.USER_TYPE = ''Admin'' THEN',
'        -- Insert into ADMINS table using the values from USERS_INFO',
'        INSERT INTO ADMINS (USER_ID, NAME, EMAIL, PASSWORD)',
'        VALUES (:NEW.USER_ID, :NEW.NAME, :NEW.EMAIL, :NEW.PASSWORD);',
'    END IF;',
'END;',
'/',
'create or replace TRIGGER TRG_INSERT_DONOR',
'AFTER INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Donor''',
'    IF :NEW.USER_TYPE = ''Donor'' THEN',
'        -- Insert into DONOR_INFO table',
'        INSERT INTO DONOR_INFO (',
'            USER_ID, BLOOD_GROUP, ADDRESS, DISTRICT, EMERGENCY_CONTACT, CONTACT_NO_2, ',
'            LIVING_AREA, LIVING_AREA_CODE, NAME, EMAIL',
'        )',
'        VALUES (',
'            :NEW.USER_ID,      -- User ID from USERS_INFO',
'            NULL,              -- BLOOD_GROUP to be updated later',
'            NULL,              -- ADDRESS to be updated later',
'            NULL,              -- DISTRICT to be updated later',
'            NULL,              -- Default value for EMERGENCY_CONTACT',
'            NULL,              -- CONTACT_NO_2 to be updated later',
'            NULL,              -- LIVING_AREA to be updated later',
'            NULL,              -- LIVING_AREA_CODE to be updated later',
'            :NEW.NAME,         -- Name from USERS_INFO',
'            :NEW.EMAIL         -- Email from USERS_INFO',
'        );',
'    END IF;',
'END;',
'/',
'create or replace TRIGGER TRG_INSERT_RECIPIENT',
'AFTER INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Recipient''',
'    IF :NEW.USER_TYPE = ''General'' THEN',
'        -- Insert into RECIPIENT_INFO table',
'        INSERT INTO RECIPIENT_INFO (USER_ID, CONTACT_NO_1, CONTACT_NO_2, ADDRESS, NAME, EMAIL)',
'        VALUES (',
'            :NEW.USER_ID,   -- User ID from USERS_INFO',
'            NULL,           -- CONTACT_NO_1 to be updated later',
'            NULL,           -- CONTACT_NO_2 to be updated later',
'            NULL,           -- ADDRESS to be updated later',
'            :NEW.NAME,      -- Name from USERS_INFO',
'            :NEW.EMAIL      -- Email from USERS_INFO',
'        );',
'    END IF;',
'END;',
'/',
'create or replace TRIGGER trg_notification_id',
'BEFORE INSERT ON NOTIFICATIONS',
'FOR EACH ROW',
'BEGIN',
'    :NEW.NOTIFICATION_ID := ''NOTI-'' || LPAD(notification_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER trg_patient_id',
'BEFORE INSERT ON PATIENT_INFO',
'FOR EACH ROW',
'BEGIN',
'    :NEW.PATIENT_ID := ''PAT-'' || LPAD(patient_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER TRG_UPDATE_DONOR',
'AFTER UPDATE ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    -- Check if the USER_TYPE is ''Donor''',
'    IF :OLD.USER_TYPE = ''Donor'' THEN',
'        -- Update the DONOR_INFO table with the new data',
'        UPDATE DONOR_INFO',
'        SET ',
'            NAME = :NEW.NAME,',
'            EMAIL = :NEW.EMAIL,',
'            ADDRESS = :NEW.ADDRESS,',
'            DISTRICT = :NEW.DISTRICT,',
'            EMERGENCY_CONTACT = :NEW.EMERGENCY_CONTACT,',
'            CONTACT_NO_2 = :NEW.CONTACT_NO_2,',
'            LIVING_AREA = :NEW.LIVING_AREA,',
'            LIVING_AREA_CODE = :NEW.LIVING_AREA_CODE',
'        WHERE USER_ID = :OLD.USER_ID;',
'    END IF;',
'END;',
'/',
'create or replace TRIGGER trg_update_donor_info',
'AFTER UPDATE ON DONOR_HEALTH',
'FOR EACH ROW',
'BEGIN',
'    UPDATE DONOR_INFO',
'    SET ',
'        CONTACT_NO_1 = :NEW.EMERGENCY_CONTACT',
'    WHERE USER_ID = :NEW.USERS_INFO_USER_ID;',
'',
'    -- Optionally, handle insert if no matching record exists',
'    IF SQL%ROWCOUNT = 0 THEN',
'        INSERT INTO DONOR_INFO (',
'            USER_ID, ',
'            BLOOD_GROUP, ',
'            ADDRESS, ',
'            DISTRICT, ',
'            CONTACT_NO_1, ',
'            CONTACT_NO_2, ',
'            LIVING_AREA, ',
'            NAME, ',
'            EMAIL, ',
'            LIVING_AREA_CODE, ',
'            LATITUDE, ',
'            LONGITUDE',
'        )',
'        VALUES (',
'            :NEW.USERS_INFO_USER_ID,',
'            NULL, -- Set default or dynamic values',
'            NULL,',
'            NULL,',
'            :NEW.EMERGENCY_CONTACT,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL,',
'            NULL',
'        );',
'    END IF;',
'END;',
'/',
'create or replace TRIGGER trg_user_id',
'BEFORE INSERT ON USERS_INFO',
'FOR EACH ROW',
'BEGIN',
'    :NEW.USER_ID := ''USR-'' || LPAD(user_seq.NEXTVAL, 5, ''0'');',
'END;',
'/',
'create or replace TRIGGER UPDATE_PATIENT_HOSPITAL_DETAILS',
'AFTER INSERT ON DONATION_CENTERS_HOSPITAL',
'FOR EACH ROW',
'BEGIN',
'    -- Update the PATIENT_INFO table with the center name and area from DONATION_CENTERS_HOSPITAL',
'    UPDATE PATIENT_INFO',
'    SET PATIENTS_HOSPITAL = :NEW.CENTER_NAME,',
'        HOSPITAL_AREA = :NEW.HOSPITAL_AREA',
'    WHERE DONATION_CENTERS_CENTER_ID = :NEW.CENTER_ID;',
'END;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472443472522610151)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_BLOOD_BANK_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472443609420610151)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_CENTER_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472443894761610151)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_DONATION_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472444073977610151)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_FEEDBACK_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472444265937610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_INSERT_ADMIN'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472444482738610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_INSERT_DONOR'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472444686346610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_INSERT_RECIPIENT'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472444843041610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_NOTIFICATION_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472445049063610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_PATIENT_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472445230975610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_UPDATE_DONOR'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472445408733610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_UPDATE_DONOR_INFO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472445657051610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'TRG_USER_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9472445885186610152)
,p_script_id=>wwv_flow_imp.id(9472443382508610149)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'UPDATE_PATIENT_HOSPITAL_DETAILS'
);
wwv_flow_imp.component_end;
end;
/
