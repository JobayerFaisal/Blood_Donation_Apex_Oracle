prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'PATIENT DETAILS'
,p_alias=>'PATIENT-DETAILS'
,p_step_title=>'PATIENT DETAILS'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-BreadcrumbRegion {',
'    --ut-breadcrumb-padding-y: .5rem;',
'    background: url(''#APP_FILES#istockphoto-1405271032-612x612.jpg'') no-repeat center center;',
'    background-size: cover;  /* Ensures the image covers the entire region */',
'    height: 100px;  /* Sets the height of the breadcrumb region to 100px */',
'    width: 100%;  /* Ensures the background image spans the full width */',
'}',
'',
'',
'.t-Region{',
'background-color: #f8f8f8;}',
'',
'',
'',
'.t-Region-header {',
'    background-color: #8B0000;  /* Off-white background color */',
'    color: #f8f8f8;  /* Blood red text color */',
'    padding: 10px 15px;  /* Optional: Adjust padding for better spacing */',
'    border-radius: 5px;  /* Optional: Add rounded corners */',
'}',
'',
'',
'',
'',
'',
'.t-Header-nav {',
'    --a-menubar-background-color: #8A0707; /* Blood red color */',
'    --a-menubar-item-text-color: #FFFFFF; /* White text color */',
'    --a-menubar-item-current-background-color: #730606; /* Darker blood red for the current item */',
'    --a-menubar-item-current-text-color: #FFFFFF; /* White text for the current item */',
'    --a-menubar-item-focused-background-color: #9B0A0A; /* Slightly lighter blood red for hover/focus */',
'    --a-menubar-item-focused-text-color: #FFFFFF; /* White text for hover/focus */',
'    --a-menubar-item-border-color: #8A0707; /* Match border to menubar background */',
'    --a-menubar-item-border-width: 1px;',
'    --a-menubar-item-padding-y: .875rem;',
'    --a-menubar-item-padding-x: 1.25rem;',
'    --a-menubar-item-font-size: .875rem;',
'    --a-menubar-item-line-height: 1.25rem;',
'    --a-menubar-item-split-icon-color: #FFFFFF; /* White color for split icons */',
'    --a-menubar-item-split-border-color: #730606; /* Match split border to darker blood red */',
'    --a-menubar-item-split-border-width: 0px;',
'    z-index: 790;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1028826035514987819)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(86821983938301805357)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1718435685217885827)
,p_plug_name=>'MATCHED DONORS'
,p_title=>'MATCHED DONORS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(110174893566959025837)
,p_plug_name=>'MATCHED DONORS'
,p_parent_plug_id=>wwv_flow_imp.id(1718435685217885827)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    DI.NAME,',
'    DI.BLOOD_GROUP,',
'    DI.CONTACT_NO_2 AS DONOR_CONTACT_NO',
'',
'FROM ',
'    DONOR_INFO DI',
'JOIN ',
'    PATIENT_INFO PI',
'    ON DI.BLOOD_GROUP = PI.BLOOD_GROUP',
'JOIN ',
'    USERS_INFO UI',
'    ON PI.USERS_INFO_USER_ID = UI.USER_ID',
'WHERE ',
'    UPPER(UI.NAME) = UPPER(:APP_USER);',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1718434104699885812)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1792002849557034624)
,p_name=>'BLOOD_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BLOOD_GROUP'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Blood Group'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2303027531906578735)
,p_name=>'DONOR_CONTACT_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DONOR_CONTACT_NO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Donor Contact No'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>22
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(1718433387234885804)
,p_internal_uid=>1718433387234885804
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1725455163936023315)
,p_interactive_grid_id=>wwv_flow_imp.id(1718433387234885804)
,p_static_id=>'17254552'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1725455315669023315)
,p_report_id=>wwv_flow_imp.id(1725455163936023315)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1725462195581023331)
,p_view_id=>wwv_flow_imp.id(1725455315669023315)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(1718434104699885812)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(2300694545900230109)
,p_view_id=>wwv_flow_imp.id(1725455315669023315)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(1792002849557034624)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(2619856931106025503)
,p_view_id=>wwv_flow_imp.id(1725455315669023315)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(2303027531906578735)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2303025728215578717)
,p_plug_name=>'MATCHED NEARBY DONORS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2303025881346578718)
,p_plug_name=>'MATCHED NEARBY DONORS'
,p_title=>'MATCHED NEARBY DONORS'
,p_parent_plug_id=>wwv_flow_imp.id(2303025728215578717)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    d.NAME AS DONOR_NAME,',
'    d.BLOOD_GROUP AS DONOR_BLOOD_GROUP,',
'    d.CONTACT_NO_2 AS DONOR_CONTACT_NO,',
'    d.LIVING_AREA',
'FROM ',
'    DONOR_INFO d',
'JOIN ',
'    PATIENT_INFO p',
'ON ',
'    d.BLOOD_GROUP = p.BLOOD_GROUP',
'JOIN ',
'    USERS_INFO UI',
'ON ',
'    p.USERS_INFO_USER_ID = UI.USER_ID',
'WHERE ',
'    UPPER(UI.NAME) = UPPER(:APP_USER)',
'     AND d.LIVING_AREA = p.HOSPITAL_AREA ;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'MATCHED NEARBY DONORS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2303025995680578719)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'2022-2-60-130@STD.EWUBD.EDU'
,p_internal_uid=>2303025995680578719
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2303027186692578731)
,p_db_column_name=>'DONOR_NAME'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Donor Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2303027273549578732)
,p_db_column_name=>'DONOR_BLOOD_GROUP'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Donor Blood Group'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2303027325561578733)
,p_db_column_name=>'DONOR_CONTACT_NO'
,p_display_order=>30
,p_column_identifier=>'H'
,p_column_label=>'Donor Contact No'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2303027457845578734)
,p_db_column_name=>'LIVING_AREA'
,p_display_order=>40
,p_column_identifier=>'I'
,p_column_label=>'Living Area'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2311873834717711828)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'23118739'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(110174893443167025836)
,p_plug_name=>'MY PATIENTS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(110174891307988025815)
,p_plug_name=>'MY PATIENT'
,p_title=>'MY PATIENT'
,p_parent_plug_id=>wwv_flow_imp.id(110174893443167025836)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    PI.PATIENT_NAME,',
'    PI.BLOOD_GROUP,',
'    PI.BLOOD_COUNT,',
'    PI.DONATION_DATE,',
'    PI.AGE,',
'    PI.CAUSE,',
'    PI.URGENCY_LEVEL,',
'    PI.DONATION_CENTERS_CENTER_ID,',
'    DCH.CENTER_ADDRESS,',
'    DCH.CENTER_NAME',
'FROM ',
'    PATIENT_INFO PI',
'JOIN ',
'    USERS_INFO UI',
'    ON PI.USERS_INFO_USER_ID = UI.USER_ID',
'LEFT JOIN ',
'    DONATION_CENTERS_HOSPITAL DCH',
'    ON PI.DONATION_CENTERS_CENTER_ID = DCH.CENTER_ID',
'WHERE ',
'    UPPER(UI.NAME) = UPPER(:APP_USER)',
'     AND PI.DONATION_DATE BETWEEN CURRENT_DATE - 15 AND CURRENT_DATE + 15;;',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'MY PATIENT'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_customized=>'1'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1718437679371885847)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'2022-2-60-130@STD.EWUBD.EDU'
,p_internal_uid=>1718437679371885847
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1718437730166885848)
,p_db_column_name=>'PATIENT_NAME'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Patient Name'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1718437853986885849)
,p_db_column_name=>'BLOOD_GROUP'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Blood Group'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1718437999166885850)
,p_db_column_name=>'BLOOD_COUNT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Blood Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792000580340034601)
,p_db_column_name=>'DONATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Donation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792000690334034602)
,p_db_column_name=>'AGE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Age'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792000707613034603)
,p_db_column_name=>'CAUSE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cause'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792000899371034604)
,p_db_column_name=>'URGENCY_LEVEL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Urgency Level'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792001154491034607)
,p_db_column_name=>'CENTER_NAME'
,p_display_order=>80
,p_column_identifier=>'J'
,p_column_label=>'Center Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792000927103034605)
,p_db_column_name=>'DONATION_CENTERS_CENTER_ID'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Donation Centers Center Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1792001060791034606)
,p_db_column_name=>'CENTER_ADDRESS'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Center Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1792214892784730539)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'17922149'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PATIENT_NAME:BLOOD_GROUP:BLOOD_COUNT:DONATION_DATE:AGE:CAUSE:URGENCY_LEVEL:DONATION_CENTERS_CENTER_ID:CENTER_ADDRESS:CENTER_NAME'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(110174891263399025814)
,p_button_sequence=>10
,p_button_name=>'CREATE_PATIENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--hoverIconPush'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Click Here to Request Blood.'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2303027642426578736)
,p_button_sequence=>20
,p_button_name=>'UPDATE_MY_PATIENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update My Patient Information'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
