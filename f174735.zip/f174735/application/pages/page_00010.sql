prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'PATIENT_DETAILS'
,p_alias=>'PATIENT-DETAILS2'
,p_page_mode=>'MODAL'
,p_step_title=>'PATIENT_DETAILS'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'',
'.t-Region{',
'background-color: #f8f8f8;}',
'',
'',
'',
'.t-Region-header {',
'    background-color: #8B0000;  /* Off-white background color */',
'    color: #f8f8f8;  /* Blood red text color */',
'    padding: 10px 15px;  /* Optional: Adjust padding for better spacing */',
'    border-radius: 5px;  /* Optional: Add rounded corners */',
'}'))
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1035025294001108220)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(86821983938301805357)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1035017561487108213)
,p_plug_name=>'PATIENT_DETAILS'
,p_title=>'PATIENT_DETAILS'
,p_parent_plug_id=>wwv_flow_imp.id(1035025294001108220)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    PI.PATIENT_ID,',
'       PI.BLOOD_GROUP,',
'       PI.BLOOD_COUNT,',
'       PI.DONATION_DATE,',
'       PI.AGE,',
'       PI.CAUSE,',
'       PI.URGENCY_LEVEL,',
'       PI.USERS_INFO_USER_ID,',
'       PI.PATIENTS_HOSPITAL,',
'       PI.HOSPITAL_AREA,',
'       PI.DONATION_CENTERS_CENTER_ID,',
'       PI.PATIENT_NAME,',
'       PI.PATIENT_CONTACT',
'',
'FROM ',
'    PATIENT_INFO PI',
'JOIN ',
'    USERS_INFO UI',
'    ON PI.USERS_INFO_USER_ID = UI.USER_ID',
'LEFT JOIN ',
'    DONATION_CENTERS_HOSPITAL DCH',
'    ON PI.DONATION_CENTERS_CENTER_ID = DCH.CENTER_ID',
'WHERE ',
'    UPPER(UI.NAME) = UPPER(:APP_USER);    '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'PATIENT_DETAILS'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1035017649061108213)
,p_name=>'PATIENT_DETAILS'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'PATIENT_ID'
,p_base_pk2=>'USERS_INFO_USER_ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:11:&APP_SESSION.::&DEBUG.:RP:P11_PATIENT_ID,P11_USERS_INFO_USER_ID:\#PATIENT_ID#\,\#USERS_INFO_USER_ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'2022-2-60-130@STD.EWUBD.EDU'
,p_internal_uid=>1035017649061108213
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035018337709108214)
,p_db_column_name=>'PATIENT_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Patient ID'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035021518791108217)
,p_db_column_name=>'USERS_INFO_USER_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'I'
,p_column_label=>'Users Info User'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035018773789108215)
,p_db_column_name=>'BLOOD_GROUP'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Blood Group'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035019162777108215)
,p_db_column_name=>'BLOOD_COUNT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Blood Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035019522394108216)
,p_db_column_name=>'DONATION_DATE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Donation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035020323048108216)
,p_db_column_name=>'AGE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Age'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035020772482108217)
,p_db_column_name=>'CAUSE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Cause'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035021145672108217)
,p_db_column_name=>'URGENCY_LEVEL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Urgency Level'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035021931917108218)
,p_db_column_name=>'PATIENTS_HOSPITAL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Patients Hospital'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035022327849108218)
,p_db_column_name=>'HOSPITAL_AREA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Hospital Area'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035022751908108218)
,p_db_column_name=>'DONATION_CENTERS_CENTER_ID'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Hospital Name'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(103880220493441755681)
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1035023146251108218)
,p_db_column_name=>'PATIENT_NAME'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Patient Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2303025560143578715)
,p_db_column_name=>'PATIENT_CONTACT'
,p_display_order=>43
,p_column_identifier=>'N'
,p_column_label=>'Patient Contact'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1036128778504438923)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'10361288'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PATIENT_ID:USERS_INFO_USER_ID:BLOOD_GROUP:BLOOD_COUNT:DONATION_DATE:AGE:CAUSE:URGENCY_LEVEL:PATIENTS_HOSPITAL:HOSPITAL_AREA:DONATION_CENTERS_CENTER_ID:PATIENT_NAME'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1035023679772108219)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1035017561487108213)
,p_button_name=>'CREATE_PATIENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Click here for request blood'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1035023912909108219)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1035017561487108213)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1035024456153108219)
,p_event_id=>wwv_flow_imp.id(1035023912909108219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1035017561487108213)
);
wwv_flow_imp.component_end;
end;
/
