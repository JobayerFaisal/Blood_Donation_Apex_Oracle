prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'DONOR PROFILE'
,p_alias=>'DONOR-PROFILE'
,p_step_title=>'DONOR PROFILE'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Header-nav {',
'    --a-menubar-background-color: #8A0707; /* Blood red color */',
'    --a-menubar-item-text-color: #FFFFFF; /* White text color */',
'    --a-menubar-item-current-background-color: #730606; /* Darker blood red for the current item */',
'    --a-menubar-item-current-text-color: #FFFFFF; /* White text for the current item */',
'    --a-menubar-item-focused-background-color: #9B0A0A; /* Slightly lighter blood red for hover/focus */',
'    --a-menubar-item-focused-text-color: #FFFFFF; /* White text for hover/focus */',
'    --a-menubar-item-border-color: #8A0707; /* Match border to menubar background */',
'    --a-menubar-item-border-width: 1px;',
'    --a-menubar-item-padding-y: .875rem;',
'    --a-menubar-item-padding-x: 1.25rem;',
'    --a-menubar-item-font-size: .875rem;',
'    --a-menubar-item-line-height: 1.25rem;',
'    --a-menubar-item-split-icon-color: #FFFFFF; /* White color for split icons */',
'    --a-menubar-item-split-border-color: #730606; /* Match split border to darker blood red */',
'    --a-menubar-item-split-border-width: 0px;',
'    z-index: 790;',
'}',
'',
'',
'',
'.t-BreadcrumbRegion {',
'    --ut-breadcrumb-padding-y: .5rem;',
'    background-image: url(''#APP_FILES#istockphoto-1405271032-612x612.jpg''); /* Replace ''your-image-url.jpg'' with the actual image path */',
'    background-size: cover; /* Ensures the image covers the entire breadcrumb area */',
'    background-position: center; /* Centers the image */',
'    background-repeat: no-repeat; /* Prevents the image from repeating */',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(2704058391477241480)
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1818119358452893205)
,p_plug_name=>'DONOR PROFILE '
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT USER_ID, NAME, BLOOD_GROUP, ADDRESS, DISTRICT, EMERGENCY_CONTACT, CONTACT_NO_2,',
'       LIVING_AREA, EMAIL, LIVING_AREA_CODE, LATITUDE, LONGITUDE, AGE, WEIGHT, ',
'       HEALTH_CONDITION, CHRONIC_CONDITION, AVAILIBILITY',
'FROM DONOR_INFO',
'WHERE USER_ID = :G_USER_ID;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Donor Profile'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1818119456574893205)
,p_name=>'Donor Profile'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'USER_ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:17:&APP_SESSION.::&DEBUG.:RP:P17_USER_ID:\#USER_ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'AKASH_SAHA'
,p_internal_uid=>1818119456574893205
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818120127663893206)
,p_db_column_name=>'USER_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'User'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818122953462893208)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818120525725893207)
,p_db_column_name=>'BLOOD_GROUP'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Blood Group'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818120936617893207)
,p_db_column_name=>'ADDRESS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818121338259893207)
,p_db_column_name=>'DISTRICT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'District'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818122101379893208)
,p_db_column_name=>'CONTACT_NO_2'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Contact No'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818121782064893208)
,p_db_column_name=>'EMERGENCY_CONTACT'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Emergency Contact'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818122582189893208)
,p_db_column_name=>'LIVING_AREA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Living Area'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818123300162893209)
,p_db_column_name=>'EMAIL'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818123751213893209)
,p_db_column_name=>'LIVING_AREA_CODE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Living Area Code'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818124159014893209)
,p_db_column_name=>'LATITUDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Latitude'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818124509317893210)
,p_db_column_name=>'LONGITUDE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Longitude'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818124988526893210)
,p_db_column_name=>'AGE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Age'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818125333928893210)
,p_db_column_name=>'WEIGHT'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Weight'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818125716187893210)
,p_db_column_name=>'HEALTH_CONDITION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Health Condition'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818126156553893211)
,p_db_column_name=>'CHRONIC_CONDITION'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Chronic Condition'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1818126581849893211)
,p_db_column_name=>'AVAILIBILITY'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Availibility'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1823097362664747026)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'18230974'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USER_ID:BLOOD_GROUP:ADDRESS:DISTRICT:EMERGENCY_CONTACT:CONTACT_NO_2:LIVING_AREA:NAME:EMAIL:LIVING_AREA_CODE:LATITUDE:LONGITUDE:AGE:WEIGHT:HEALTH_CONDITION:CHRONIC_CONDITION:AVAILIBILITY'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1818128644138893212)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(86821983938301805357)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1818127367048893211)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1818119358452893205)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1818127801656893212)
,p_event_id=>wwv_flow_imp.id(1818127367048893211)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1818119358452893205)
);
wwv_flow_imp.component_end;
end;
/
