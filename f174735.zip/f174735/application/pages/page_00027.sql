prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>'CHARTS'
,p_alias=>'DONOR-COUNT'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Header-nav {',
'    --a-menubar-background-color: #8A0707; /* Blood red color */',
'    --a-menubar-item-text-color: #FFFFFF; /* White text color */',
'    --a-menubar-item-current-background-color: #730606; /* Darker blood red for the current item */',
'    --a-menubar-item-current-text-color: #FFFFFF; /* White text for the current item */',
'    --a-menubar-item-focused-background-color: #9B0A0A; /* Slightly lighter blood red for hover/focus */',
'    --a-menubar-item-focused-text-color: #FFFFFF; /* White text for hover/focus */',
'    --a-menubar-item-border-color: #8A0707; /* Match border to menubar background */',
'    --a-menubar-item-border-width: 1px;',
'    --a-menubar-item-padding-y: .875rem;',
'    --a-menubar-item-padding-x: 1.25rem;',
'    --a-menubar-item-font-size: .875rem;',
'    --a-menubar-item-line-height: 1.25rem;',
'    --a-menubar-item-split-icon-color: #FFFFFF; /* White color for split icons */',
'    --a-menubar-item-split-border-color: #730606; /* Match split border to darker blood red */',
'    --a-menubar-item-split-border-width: 0px;',
'    z-index: 790;',
'}',
'',
'',
'',
'.t-Region-header {',
'    align-items: center;',
'    background-color: #8A0707; /* Blood red background color */',
'    border-block-end-color: var(--ut-region-header-border-color, var(--ut-region-border-color, rgba(0, 0, 0, .075)));',
'    border-block-end-style: solid;',
'    border-block-end-width: var(--ut-region-header-border-width, var(--ut-region-border-width, 1px));',
'    border-top-left-radius: var(--ut-region-border-radius, var(--ut-component-border-radius));',
'    border-top-right-radius: var(--ut-region-border-radius, var(--ut-component-border-radius));',
'    color: #FFFFFF; /* White text color */',
'    display: flex;',
'    font-size: var(--ut-region-header-font-size, 1rem);',
'    font-weight: var(--a-base-font-weight-semibold, 500);',
'    line-height: var(--ut-region-header-line-height, 1.5rem);',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2659457568928577704)
,p_plug_name=>'Requested Blood Groups'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'PATIENT_INFO'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(2659458199416577710)
,p_region_id=>wwv_flow_imp.id(2659457568928577704)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(2659458249002577711)
,p_chart_id=>wwv_flow_imp.id(2659458199416577710)
,p_seq=>10
,p_name=>'Most searched blood'
,p_data_source_type=>'TABLE'
,p_query_table=>'PATIENT_INFO'
,p_include_rowid_column=>false
,p_items_label_column_name=>'BLOOD_GROUP'
,p_aggregate_function=>'COUNT'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2659458594072577714)
,p_plug_name=>'Cause-Wise Breakdown of Blood Requests'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(2659458656597577715)
,p_region_id=>wwv_flow_imp.id(2659458594072577714)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(2659458796311577716)
,p_chart_id=>wwv_flow_imp.id(2659458656597577715)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'TABLE'
,p_query_table=>'PATIENT_INFO'
,p_include_rowid_column=>false
,p_items_label_column_name=>'CAUSE'
,p_aggregate_function=>'COUNT'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2703042542704232307)
,p_plug_name=>'Distribution of Donors by Blood Group'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(2703044471104232307)
,p_region_id=>wwv_flow_imp.id(2703042542704232307)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_indicator_size=>1
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(2703046112145232308)
,p_chart_id=>wwv_flow_imp.id(2703044471104232307)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'TABLE'
,p_query_table=>'DONOR_INFO'
,p_series_type=>'pie'
,p_group_short_desc_column_name=>'BLOOD_GROUP'
,p_items_label_column_name=>'BLOOD_GROUP'
,p_aggregate_function=>'COUNT'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_gantt_start_date_source=>'DB_COLUMN'
,p_gantt_end_date_source=>'DB_COLUMN'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp.component_end;
end;
/
