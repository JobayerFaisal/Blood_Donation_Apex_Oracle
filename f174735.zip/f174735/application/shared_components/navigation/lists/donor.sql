prompt --application/shared_components/navigation/lists/donor
begin
--   Manifest
--     LIST: DONOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2746796625753109458)
,p_name=>'DONOR'
,p_list_status=>'PUBLIC'
,p_version_scn=>15600472923846
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2747011370542113620)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'HOMEPAGE'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2747011909163113621)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'PATIENT DETAILS'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2747012548151113621)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'DONOR LIST'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2747013441157113621)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'DONOR PROFILE'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2747014365234113621)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'BLOOD DONATION INSIGHTS'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
