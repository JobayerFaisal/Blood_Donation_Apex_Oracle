prompt --application/shared_components/security/authentications/c_o_1
begin
--   Manifest
--     AUTHENTICATION: C_O_1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(99861820342041205695)
,p_name=>'C_O_1'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'my_authentication'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function my_authentication (',
'    p_username in varchar2,',
'    p_password in varchar2 )',
'    return boolean',
'is',
'    l_username USERS_INFO.NAME%type := lower(p_username);',
'    l_user_id   USERS_INFO.USER_ID%type;',
'    l_password USERS_INFO.PASSWORD%type;',
'',
'',
'    begin',
'        select USER_ID  , PASSWORD',
'          into l_user_id, l_password',
'          from USERS_INFO',
'         where lower(NAME) = l_username;',
'    ',
'    if p_password = l_password then',
'    :G_USER_ID := l_user_id;',
'    return true;',
'    end if;',
'',
'    return false;',
'',
'',
'    exception ',
'    when no_data_found then',
'        return false; -- User not found',
'    when too_many_rows then',
'        return false; -- Duplicate usernames (unexpected)',
'    when others then',
'        -- Log unexpected errors',
'        return false;',
'end;',
''))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>15595086647094
);
wwv_flow_imp.component_end;
end;
/
