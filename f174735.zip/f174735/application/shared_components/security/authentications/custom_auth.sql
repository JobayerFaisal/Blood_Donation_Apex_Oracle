prompt --application/shared_components/security/authentications/custom_auth
begin
--   Manifest
--     AUTHENTICATION: Custom_Auth
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(99807197193277500005)
,p_name=>'Custom_Auth'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'RETURN CUSTOM_AUTHENTICATION(:P9999_USERNAME, :P9999_PASSWORD);'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>15595067797260
);
wwv_flow_imp.component_end;
end;
/
