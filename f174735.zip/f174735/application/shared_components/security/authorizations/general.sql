prompt --application/shared_components/security/authorizations/general
begin
--   Manifest
--     SECURITY SCHEME: GENERAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(2686400836623369854)
,p_name=>'GENERAL'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_user_type VARCHAR2(15);',
'BEGIN',
'  SELECT USER_TYPE INTO v_user_type FROM USERS_INFO WHERE USER_ID = :G_USER_ID;',
'  RETURN v_user_type = ''General'';',
'END;',
''))
,p_version_scn=>15600456691692
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
