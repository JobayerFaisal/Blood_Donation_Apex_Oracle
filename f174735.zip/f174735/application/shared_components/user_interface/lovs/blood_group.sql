prompt --application/shared_components/user_interface/lovs/blood_group
begin
--   Manifest
--     BLOOD_GROUP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1744048602826960064)
,p_lov_name=>'BLOOD_GROUP'
,p_lov_query=>'.'||wwv_flow_imp.id(1744048602826960064)||'.'
,p_location=>'STATIC'
,p_version_scn=>15600041618126
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744048915329960066)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'A+ (A Positive)'
,p_lov_return_value=>'A+'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744049307399960066)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'A- (A Negative)'
,p_lov_return_value=>'A-'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744049714505960066)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'B+ (B Positive)'
,p_lov_return_value=>'B+'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744050196924960066)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'B- (B Negative)'
,p_lov_return_value=>'B-'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744050544224960067)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'AB+ (AB Positive)'
,p_lov_return_value=>'AB+'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744050904636960067)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'AB- (AB Negative)'
,p_lov_return_value=>'AB-'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744051319125960067)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>'O+ (O Positive)'
,p_lov_return_value=>'O+'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1744051773785960067)
,p_lov_disp_sequence=>8
,p_lov_disp_value=>'O- (O Negative)'
,p_lov_return_value=>'O-'
);
wwv_flow_imp.component_end;
end;
/
