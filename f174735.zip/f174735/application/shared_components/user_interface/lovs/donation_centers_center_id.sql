prompt --application/shared_components/user_interface/lovs/donation_centers_center_id
begin
--   Manifest
--     DONATION_CENTERS.CENTER_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(103880220493441755681)
,p_lov_name=>'DONATION_CENTERS.CENTER_ID'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'DONATION_CENTERS_HOSPITAL'
,p_return_column_name=>'CENTER_ID'
,p_display_column_name=>'CENTER_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'CENTER_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15598892784484
);
wwv_flow_imp.component_end;
end;
/
