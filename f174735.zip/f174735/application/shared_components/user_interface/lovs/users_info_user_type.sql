prompt --application/shared_components/user_interface/lovs/users_info_user_type
begin
--   Manifest
--     USERS_INFO.USER_TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(100367852696323003951)
,p_lov_name=>'USERS_INFO.USER_TYPE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'USERS_INFO'
,p_return_column_name=>'USER_ID'
,p_display_column_name=>'USER_TYPE'
,p_default_sort_column_name=>'USER_TYPE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15595298119255
);
wwv_flow_imp.component_end;
end;
/
