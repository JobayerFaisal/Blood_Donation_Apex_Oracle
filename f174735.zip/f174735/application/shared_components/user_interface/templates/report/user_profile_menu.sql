prompt --application/shared_components/user_interface/templates/report/user_profile_menu
begin
--   Manifest
--     ROW TEMPLATE: USER_PROFILE_MENU
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(1749901912759092596)
,p_row_template_name=>'USER_PROFILE_MENU'
,p_internal_name=>'USER_PROFILE_MENU'
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="accountMenu_menu" class="a-Header-accountDialog" tabindex="-1">',
'    <div class="a-MediaBlock a-Menu-content">',
'        <div class="a-MediaBlock-graphic">',
'            <span class="a-Header-userPhoto a-Header-userPhoto--large">',
'        <img src="#IMAGE#" height="64" width="64" class="a-Header-photo" alt="Profile image for user #FIRSTNAME#">',
'      </span>',
'            <a href="#EDIT_PROFIL#" class="a-Header-accountDialog-editProfile a-Menu-item a-Menu-label" id="EDIT_PROFILE_LINK">Edit Profile</a>',
'        </div>',
'        <div class="a-MediaBlock-content">',
'            <div class="a-Menu-label a-Menu-item" tabindex="-1">',
'                <span class="a-Header-dialogText a-Header-dialogName">#FIRSTNAME# #LASTNAME#</span>',
'                <span class="a-Header-dialogText a-Header-dialogUsername">#EMAIL#</span></div>',
'            <div class="a-Menu-label a-Menu-item" tabindex="-1">',
'                <span class="a-Header-dialogLabel">',
'Workspace</span><span class="a-Header-dialogValue">#WORKSPACE#</span></div>',
'            <div class="a-Menu-label a-Menu-item" tabindex="-1">',
'                <span class="a-Header-dialogLabel">Role</span><span class="a-Header-dialogValue">#ROLE#</span></div>',
'        </div>',
'    </div>',
'</div>',
''))
,p_row_template_before_rows=>' '
,p_row_template_after_rows=>' '
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>4
,p_translate_this_template=>'N'
);
wwv_flow_imp.component_end;
end;
/
