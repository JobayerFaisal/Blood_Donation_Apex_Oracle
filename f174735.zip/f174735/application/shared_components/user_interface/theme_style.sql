prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 174735
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(100018022562227159131)
,p_theme_id=>42
,p_name=>'Vita - Dark (copy_1)'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Header-BG":"#c8052c","@g_Header-FG":"#ffffff","@g_Accent-BG":"#c80525","@irrBg":"#261f21"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#100018022562227159131.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
