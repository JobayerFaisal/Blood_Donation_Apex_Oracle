prompt --workspace/credentials/app_174735_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 174735 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>81199658429634758193
,p_default_application_id=>174735
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BLOODDONATIONSYSTEM'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(86822658663259806290)
,p_name=>'App 174735 Push Notifications Credentials'
,p_static_id=>'App_174735_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
